import cv2
import mediapipe as mp
import numpy as np
import os
import time
import threading
import signal
import sys
import subprocess
from multiprocessing import Process
from PCA9685 import PCA9685
import errno
import fcntl

# 设置FIFO路径
FIFO_PATH = "/tmp/gesture_fifo"
# 创建FIFO（如果不存在）
if not os.path.exists(FIFO_PATH):
    os.mkfifo(FIFO_PATH)

# 设置环境变量禁用SVE检测
os.environ['OPENBLAS_CORETYPE'] = 'ARMV8'
couter = 0

# 自动清理摄像头残留进程
def cleanup_camera_processes():
    try:
        # 使用lsof命令查找占用摄像头的进程
        result = subprocess.run(['lsof', '/dev/video0'], capture_output=True, text=True)
        output = result.stdout
        
        # 解析输出获取PID
        pids = []
        for line in output.split('\n')[1:]:  # 跳过标题行
            if line.strip():
                parts = line.split()
                try:
                    pid = int(parts[1])
                    pids.append(pid)
                except (IndexError, ValueError):
                    continue
        
        # 终止除当前进程外的所有进程
        current_pid = os.getpid()
        for pid in pids:
            if pid != current_pid:
                print(f"检测到占用摄像头的残留进程 PID: {pid}，正在终止...")
                os.kill(pid, 9)  # 强制终止
                time.sleep(0.1)  # 等待进程终止
                
    except Exception as e:
        print(f"清理摄像头进程时出错: {e}")

# 信号处理确保资源释放
def signal_handler(sig, frame):
    global camera, reader_process
    print(f"\n收到信号 {sig}，正在清理资源...")
    if camera:
        camera.stop()
    if reader_process and reader_process.is_alive():
        reader_process.terminate()
    cv2.destroyAllWindows()
    sys.exit(0)

# 初始化Mediapipe手部检测
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    model_complexity=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.3
)
mp_drawing = mp.solutions.drawing_utils

# Servo pin definitions (adjust according to your wiring)
SERVO1_PIN = 17
SERVO2_PIN = 18
SERVO3_PIN = 22
SERVO4_PIN = 23
# WSERVO_PIN = 24  # Tail servo

# Global variables
Action_Mode = 2  # Default mode
WeiBa = 0  # Tail control flag
Sustainedmove = 0
SpeedDelay = 80  # Default speed delay in ms
SwingDelay = 15  # Default swing delay in ms
Chongfunumber = 2  # Action repeat count
SwingRepeatnumber = 3
HelloRepeatnumber = 4
PAnumbers = Chongfunumber
TiaoTurn = 0
TiaoTurn2 = 0


def setup_fifo():
    """确保 FIFO 文件存在"""
    try:
        os.mkfifo(FIFO_PATH)
    except OSError as oe:
        if oe.errno != errno.EEXIST:
            raise


def read_fifo_non_blocking():
    """非阻塞方式读取 FIFO"""
    print(f"以非阻塞方式从 {FIFO_PATH} 读取数据...")
    try:
        # 直接使用 os.open + os.read，避免 fdopen 影响非阻塞标志
        fifo_fd = os.open(FIFO_PATH, os.O_RDONLY | os.O_NONBLOCK)
        while True:
            try:
                # 使用 os.read 替代 f.read()，避免阻塞
                data = os.read(fifo_fd, 4096)  # 4096 是缓冲区大小
                if data:
                    return data.decode('utf-8')  # 转换为字符串
                else:
                    time.sleep(0.1)  # 避免 CPU 占用过高
            except OSError as e:
                if e.errno == errno.EAGAIN or e.errno == errno.EWOULDBLOCK:
                    time.sleep(0.1)
                    continue
                raise
    except KeyboardInterrupt:
        print("\n读取中断")
    finally:
        os.close(fifo_fd)  # 确保关闭文件描述符


# Angle to duty cycle conversion
def angle_to_duty(angle):
    return int((angle * 2000 / 180) + 500)


# Servo control functions
def Servo_Angle1(angle):
    duty = angle_to_duty(angle)
    # pwm1.ChangeDutyCycle(duty)
    pwm.setServoPulse(0, duty)


def Servo_Angle2(angle):
    angle = 180 - angle
    duty = angle_to_duty(angle)
    # pwm1.ChangeDutyCycle(duty)
    pwm.setServoPulse(1, duty)


def Servo_Angle3(angle):
    duty = angle_to_duty(angle)
    # pwm1.ChangeDutyCycle(duty)
    pwm.setServoPulse(2, duty)


def Servo_Angle4(angle):
    angle = 180 - angle
    duty = angle_to_duty(angle)
    # pwm1.ChangeDutyCycle(duty)
    pwm.setServoPulse(3, duty)


# def WServo_Angle(angle):
#     duty = angle_to_duty(angle)
#     pwmW.ChangeDutyCycle(duty)


# Delay function (in milliseconds)
def Delay_ms(ms):
    time.sleep(ms / 1000.0)


# Action functions
def Action_relaxed_getdowm():
    Servo_Angle1(20)
    Servo_Angle2(20)
    Delay_ms(80)
    Servo_Angle3(160)
    Servo_Angle4(160)


def Action_upright():
    Servo_Angle1(90)
    Servo_Angle2(90)
    Delay_ms(80)
    Servo_Angle3(90)
    Servo_Angle4(90)

    if WeiBa == 1:
        global Action_Mode
        Action_Mode = 9


def Action_upright2():
    Servo_Angle3(90)
    Servo_Angle4(90)
    Delay_ms(80)
    Servo_Angle1(90)
    Servo_Angle2(90)

    if WeiBa == 1:
        global Action_Mode
        Action_Mode = 9


def Action_getdowm():
    Servo_Angle1(20)
    Servo_Angle2(20)
    Delay_ms(80)
    Servo_Angle3(20)
    Servo_Angle4(20)

    if WeiBa == 1:
        global Action_Mode
        Action_Mode = 9


def Action_sit():
    Servo_Angle1(90)
    Servo_Angle2(90)
    Delay_ms(80)
    Servo_Angle3(20)
    Servo_Angle4(20)

    if WeiBa == 1:
        global Action_Mode
        Action_Mode = 9


def Action_advance():
    global Action_Mode, PAnumbers, Sustainedmove

    while Action_Mode == 4:
        PAnumbers = Chongfunumber
        while (PAnumbers or Sustainedmove) and Action_Mode == 4:
            Servo_Angle2(45)
            Servo_Angle3(45)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break
            Servo_Angle1(135)
            Servo_Angle4(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break
            Servo_Angle2(90)
            Servo_Angle3(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break
            Servo_Angle1(90)
            Servo_Angle4(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break

            Servo_Angle1(45)
            Servo_Angle4(45)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break
            Servo_Angle2(135)
            Servo_Angle3(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break
            Servo_Angle1(90)
            Servo_Angle4(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break
            Servo_Angle2(90)
            Servo_Angle3(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 4:
                break

            PAnumbers -= 1

        if not Sustainedmove and Action_Mode == 4:
            Action_Mode = 2


def Action_back():
    global Action_Mode, PAnumbers, Sustainedmove

    while Action_Mode == 5:
        PAnumbers = Chongfunumber
        while (PAnumbers or Sustainedmove) and Action_Mode == 5:
            Servo_Angle2(135)
            Servo_Angle3(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break
            Servo_Angle1(45)
            Servo_Angle4(45)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break
            Servo_Angle2(90)
            Servo_Angle3(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break
            Servo_Angle1(90)
            Servo_Angle4(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break

            Servo_Angle1(135)
            Servo_Angle4(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break
            Servo_Angle2(45)
            Servo_Angle3(45)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break
            Servo_Angle1(90)
            Servo_Angle4(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break
            Servo_Angle2(90)
            Servo_Angle3(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 5:
                break

            PAnumbers -= 1

        if not Sustainedmove and Action_Mode == 5:
            Action_Mode = 2


def Action_Lrotation():
    global Action_Mode, PAnumbers, Sustainedmove

    while Action_Mode == 6:
        PAnumbers = Chongfunumber + Chongfunumber
        while (PAnumbers or Sustainedmove) and Action_Mode == 6:
            Servo_Angle2(45)
            Servo_Angle3(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 6:
                break
            Servo_Angle1(45)
            Servo_Angle4(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 6:
                break
            Servo_Angle2(90)
            Servo_Angle3(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 6:
                break
            Servo_Angle1(90)
            Servo_Angle4(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 6:
                break

            PAnumbers -= 1

        if not Sustainedmove and Action_Mode == 6:
            Action_Mode = 2


def Action_Rrotation():
    global Action_Mode, PAnumbers, Sustainedmove

    while Action_Mode == 7:
        PAnumbers = Chongfunumber + Chongfunumber
        while (PAnumbers or Sustainedmove) and Action_Mode == 7:
            Servo_Angle1(45)
            Servo_Angle4(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 7:
                break
            Servo_Angle2(45)
            Servo_Angle3(135)
            Delay_ms(SpeedDelay)
            if Action_Mode != 7:
                break
            Servo_Angle1(90)
            Servo_Angle4(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 7:
                break
            Servo_Angle2(90)
            Servo_Angle3(90)
            Delay_ms(SpeedDelay)
            if Action_Mode != 7:
                break

            PAnumbers -= 1

        if not Sustainedmove and Action_Mode == 7:
            Action_Mode = 2


def Action_Swing():
    global Action_Mode

    SwingNumber = SwingRepeatnumber
    while SwingNumber and Action_Mode == 8:
        for i in range(30, 150):
            Servo_Angle1(i)
            Servo_Angle2(i)
            Servo_Angle3(i)
            Servo_Angle4(i)
            Delay_ms(SwingDelay)
            if Action_Mode != 8:
                break

        if Action_Mode != 8:
            break

        for i in range(150, 30, -1):
            Servo_Angle1(i)
            Servo_Angle2(i)
            Servo_Angle3(i)
            Servo_Angle4(i)
            Delay_ms(SwingDelay)
            if Action_Mode != 8:
                break

        if Action_Mode != 8:
            break

        SwingNumber -= 1

    if Action_Mode == 8:
        for i in range(30, 90):
            Servo_Angle1(i)
            Servo_Angle2(i)
            Servo_Angle3(i)
            Servo_Angle4(i)
            Delay_ms(SwingDelay)
            if Action_Mode != 8:
                break

        if Action_Mode == 8:
            Action_Mode = 2


# def Action_SwingTail():
#     global Action_Mode
#
#     SwingTailNumber = 3
#     Delay_ms(60)
#
#     while SwingTailNumber and Action_Mode == 9:
#         for i in range(30, 150):
#             WServo_Angle(i)
#             Delay_ms(SwingDelay)
#             if Action_Mode != 9:
#                 break
#
#         if Action_Mode != 9:
#             break
#
#         for i in range(150, 30, -1):
#             WServo_Angle(i)
#             Delay_ms(SwingDelay)
#             if Action_Mode != 9:
#                 break
#
#         if Action_Mode != 9:
#             break
#
#         SwingTailNumber -= 1
#
#     Delay_ms(60)


def Action_JumpU():
    global Action_Mode, TiaoTurn

    if TiaoTurn == 0:
        Servo_Angle1(140)
        Servo_Angle4(35)
        Delay_ms(SpeedDelay)

        Servo_Angle2(140)
        Servo_Angle3(35)
        Delay_ms(SpeedDelay + 80)

        Action_Mode = 2
        TiaoTurn = 1
    else:
        Servo_Angle2(140)
        Servo_Angle3(35)
        Delay_ms(SpeedDelay)

        Servo_Angle1(140)
        Servo_Angle4(35)
        Delay_ms(SpeedDelay + 80)

        Action_Mode = 2
        TiaoTurn = 0


def Action_JumpD():
    global Action_Mode, TiaoTurn2

    if TiaoTurn2 == 0:
        Servo_Angle4(35)
        Servo_Angle1(140)
        Delay_ms(SpeedDelay)

        Servo_Angle3(35)
        Servo_Angle2(140)
        Delay_ms(SpeedDelay)

        Action_Mode = 12
        TiaoTurn2 = 1
    else:
        Servo_Angle3(35)
        Servo_Angle2(140)
        Delay_ms(SpeedDelay)

        Servo_Angle4(35)
        Servo_Angle1(140)
        Delay_ms(SpeedDelay)

        Action_Mode = 12
        TiaoTurn2 = 0


def Action_Hello():
    global Action_Mode

    HelloNumber = HelloRepeatnumber

    Servo_Angle3(20)
    Servo_Angle4(45)
    Delay_ms(80)
    Servo_Angle1(90)

    while HelloNumber and Action_Mode == 13:
        if Action_Mode != 13:
            break

        for i in range(0, 46):
            if Action_Mode != 13:
                break
            Servo_Angle2(i)
            Delay_ms(SwingDelay)

        for i in range(45, -1, -1):
            if Action_Mode != 13:
                break
            Servo_Angle2(i)
            Delay_ms(SwingDelay)

        if Action_Mode != 13:
            break

        HelloNumber -= 1

    if Action_Mode == 13:
        Action_Mode = 2


def Action_stretch():
    global Action_Mode

    Servo_Angle3(90)
    Servo_Angle4(90)
    Delay_ms(80)

    for i in range(90, 9, -1):
        Servo_Angle1(i)
        Servo_Angle2(i)
        if Action_Mode != 14:
            break
        Delay_ms(15)

    for i in range(10, 91):
        Servo_Angle1(i)
        Servo_Angle2(i)
        if Action_Mode != 14:
            break
        Delay_ms(15)

    for i in range(90, 171):
        Servo_Angle3(i)
        Servo_Angle4(i)
        if Action_Mode != 14:
            break
        Delay_ms(15)

    for i in range(170, 89, -1):
        Servo_Angle3(i)
        Servo_Angle4(i)
        if Action_Mode != 14:
            break
        Delay_ms(15)

    if Action_Mode == 14:
        Action_Mode = 15


def Action_Lstretch():
    global Action_Mode

    breakvalue = True
    temp = 3

    while breakvalue:
        Servo_Angle1(90)
        Servo_Angle2(20)
        Delay_ms(60)
        Servo_Angle4(110)

        for i in range(90, 181):
            if Action_Mode != 15:
                break
            Servo_Angle3(i)
            Delay_ms(6)

        while temp and Action_Mode == 15:
            for i in range(180, 149, -1):
                if Action_Mode != 15:
                    break
                Servo_Angle3(i)
                Delay_ms(15)
            temp -= 1

        if Action_Mode != 15:
            break

        Delay_ms(100)
        Servo_Angle1(90)
        Servo_Angle2(90)
        if Action_Mode != 15:
            break
        Delay_ms(80)
        Servo_Angle3(90)
        Servo_Angle4(90)
        Delay_ms(100)
        if Action_Mode != 15:
            break

        temp = 3
        Servo_Angle2(90)
        Servo_Angle1(20)
        if Action_Mode != 15:
            break
        Delay_ms(60)
        Servo_Angle3(110)

        for i in range(90, 181):
            if Action_Mode != 15:
                break
            Servo_Angle4(i)
            Delay_ms(6)

        while temp and Action_Mode == 15:
            for i in range(180, 149, -1):
                if Action_Mode != 15:
                    break
                Servo_Angle4(i)
                Delay_ms(15)
            temp -= 1

        if Action_Mode == 15:
            Action_Mode = 2

        breakvalue = False


def test1():
    Servo_Angle1(90)
    Servo_Angle2(90)
    Servo_Angle3(90)
    Servo_Angle4(90)


# 手指计数函数
def count_fingers(landmarks, hand_label):
    tip_ids = [4, 8, 12, 16, 20]
    finger_count = 0
    if hand_label == 'Left':
        if landmarks.landmark[tip_ids[0]].x > landmarks.landmark[tip_ids[0] - 1].x:
            finger_count += 1
    else:
        if landmarks.landmark[tip_ids[0]].x < landmarks.landmark[tip_ids[0] - 1].x:
            finger_count += 1
    for id in range(1, 5):
        if landmarks.landmark[tip_ids[id]].y < landmarks.landmark[tip_ids[id] - 2].y:
            finger_count += 1
    return finger_count


# 摄像头读取线程类
class CameraReader:
    def __init__(self, src=0, width=480, height=360):
        self.cap = cv2.VideoCapture(src)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # 关键：减少缓冲区大小
        self.stopped = False
        self.frame = None
        self.thread = threading.Thread(target=self._update, daemon=True)

    def start(self):
        self.thread.start()
        return self

    def _update(self):
        while not self.stopped:
            ret, frame = self.cap.read()
            if ret:
                self.frame = frame  # 只保留最新帧

    def read(self):
        return self.frame

    def stop(self):
        self.stopped = True
        self.thread.join()
        self.cap.release()


# 创建摄像头读取器
camera = None
def reset_camera():
    """释放现有摄像头资源并重新初始化"""
    global camera
    if camera:
        print("释放旧摄像头资源...")
        camera.stop()
    print("初始化新摄像头...")
    camera = CameraReader().start()
    print("摄像头已重新初始化")

# 主循环
frame_counter = 0
prev_results = None
detection_interval = 100  # 每2帧检测一次
last_process_time = 0
max_latency = 0.1  # 最大允许处理延迟（秒）

# 记录上一次手势结果（初始值设为-1，确保首次检测触发写入）
last_gesture_result = -1

def non_blocking_write(fifo_path, data):
    """非阻塞写入FIFO，读取端未连接时不阻塞"""
    try:
        # 使用os.open设置非阻塞标志
        fifo_fd = os.open(fifo_path, os.O_WRONLY | os.O_NONBLOCK)
        with os.fdopen(fifo_fd, 'w') as fifo:
            fifo.write(f"{data}\n")
        return True
    except OSError as e:
        if e.errno == 6:  # ENXIO: 没有进程连接到FIFO（读取端未启动）
            print("警告：FIFO读取端未启动，写入被跳过")
            return False
        else:
            print(f"FIFO写入错误（OS错误）: {e}")
            return False
    except Exception as e:
        print(f"FIFO写入错误（其他）: {e}")
        return False


def supoto():
    global Action_Mode  # 声明全局变量以确保动作模式可修改
    couter = 0
    while True:
        try:
            data = read_fifo_non_blocking()
            if data:
                temadad = int(data)
                couter = couter - 1
                if couter < 0:
                    print('cou:' + str(couter) + 'temadad:' + str(temadad))
                    
                    if temadad == 0:
                        test1()
                        couter = 0
                    elif temadad == 1:
                        print('temadad:' + str(temadad))
                        Action_getdowm()
                        couter = 0
                    elif temadad == 2:
                        Action_upright()
                        couter = 0
                    elif temadad == 3:
                        Action_relaxed_getdowm()
                        couter = 0
                    elif temadad == 4:
                        Action_sit()
                        couter = 0
                    elif temadad == 5:
                        start_time = time.time()
                        duration = 5  # 总循环时间（秒）
                        interval = 0.3  # 动作间隔（秒）
                        Action_Mode = 5  # 强制进入手势5模式
                        print("开始执行手势5动作循环...")

                        # 手势5循环期间不读取新数据，确保动作不被打断
                        while (time.time() - start_time) < duration:
                            Action_sit()
                            time.sleep(interval)
                            
                            if (time.time() - start_time) >= duration:
                                break
                            
                            Action_upright()
                            time.sleep(interval)

                        print("手势5动作循环结束，恢复默认模式")
                        Action_Mode = 2  # 恢复默认站立模式
                        couter = 0  # 重置计数器
        except Exception as e:
            print(f"FIFO读取进程错误: {e}")
            time.sleep(1)

# 主程序入口
if __name__ == "__main__":
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 清理摄像头残留进程
    cleanup_camera_processes()
    
    print("=== 程序启动 ===")
    reset_camera()  # 初始摄像头设置
    
    # 初始化设置
    pwm = PCA9685(0x40)  # 对地址初始化
    pwm.setPWMFreq(50)  # 对频率初始化
    
    # 启动FIFO读取进程
    reader_process = Process(target=supoto)
    reader_process.start()
    
    try:
        while True:
            frame = camera.read()
            if frame is None:
                continue

            start_time = time.time()

            # 帧重塑与异常处理
            target_shape = (360, 480, 3)
            try:
                if frame.shape != target_shape:
                    # 检查数据大小是否匹配目标形状
                    required_pixels = np.prod(target_shape)
                    if frame.size == 529920:  # 特殊处理529920像素情况
                        print(f"检测到异常帧大小: {frame.size}，重新打开摄像头")
                        reset_camera()
                        continue  # 跳过当前帧
                    if frame.size != required_pixels:
                        raise ValueError(f"帧数据大小不匹配，需要{required_pixels}像素，实际{frame.size}")
                    frame = frame.reshape(target_shape)
            except Exception as e:
                print(f"帧转换失败，抛弃当前帧: {e}")
                continue  # 跳过当前帧的后续处理

            # 水平翻转和颜色转换
            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # 计算处理延迟
            current_time = time.time()
            process_latency = current_time - last_process_time
            last_process_time = current_time

            # 智能丢帧策略
            should_detect = (frame_counter % detection_interval == 0) and (process_latency < max_latency)

            if should_detect:
                # 执行检测
                results = hands.process(rgb_frame)
                prev_results = results
            else:
                # 使用前一次结果（跟踪模式）
                results = prev_results

            frame_counter += 1

            # 渲染结果
            output_frame = cv2.cvtColor(rgb_frame, cv2.COLOR_RGB2BGR)

            # 获取当前手势结果
            current_gesture_result = 6  # 未检测到手时默认值
            if results and results.multi_hand_landmarks:
                for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
                    hand_label = handedness.classification[0].label
                    finger_count = count_fingers(hand_landmarks, hand_label)
                    current_gesture_result = finger_count  # 0~5的手势结果

                    # 绘制手部地标和矩形框
                    mp_drawing.draw_landmarks(output_frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                    h, w, _ = output_frame.shape
                    x_list = [int(l.x * w) for l in hand_landmarks.landmark]
                    y_list = [int(l.y * h) for l in hand_landmarks.landmark]
                    cv2.rectangle(output_frame, (min(x_list) - 20, min(y_list) - 20),
                                  (max(x_list) + 20, max(y_list) + 20), (0, 255, 0), 2)
                    cv2.putText(output_frame, f"{hand_label}: {finger_count}", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            # 仅在手势结果变化时写入FIFO（非阻塞模式）
            if current_gesture_result != last_gesture_result:
                write_success = non_blocking_write(FIFO_PATH, current_gesture_result)
                if write_success:
                    last_gesture_result = current_gesture_result
                    print(f"写入FIFO: {current_gesture_result}")

            # 显示结果
            cv2.putText(output_frame, f"Gesture: {current_gesture_result}", (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv2.imshow('Low Latency Hand Detection', output_frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"发生未知错误: {e}")
    finally:
        print("清理资源中...")
        if 'camera' in locals() and camera:
            camera.stop()
            print("摄像头资源已释放")
        if 'reader_process' in locals() and reader_process.is_alive():
            reader_process.terminate()
            reader_process.join()
            print("FIFO读取进程已终止")
        cv2.destroyAllWindows()
        print("程序已安全退出")
