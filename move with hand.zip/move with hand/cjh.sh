#!/bin/bash
/home/yzh/version1_env/bin/python3 /home/yzh/cjh-test.py