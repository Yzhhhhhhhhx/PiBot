#include <opencv2/opencv.hpp>
#include <thread>
#include <chrono>
#include <vector>
#include <string>
#include <iostream>

int main() {
    std::string emotion = "sad";  // 要播放的情绪
    std::string folder_path = "/home/yzh/Desktop/fer_detection/emotions/emotions/" + emotion;
    int frame_count = 47;  // 对应情绪的帧数

    // 设置你实际的屏幕分辨率（例如树莓派LCD：800x480）
    int screen_width = 800;
    int screen_height = 480;

    // 创建窗口并设置为全屏
    cv::namedWindow("Emotion Player", cv::WINDOW_NORMAL);
    cv::setWindowProperty("Emotion Player", cv::WND_PROP_FULLSCREEN, cv::WINDOW_FULLSCREEN);

    while (true) {
        for (int i = 0; i < frame_count; ++i) {
            std::string image_path = folder_path + "/frame" + std::to_string(i) + ".png";
            cv::Mat img = cv::imread(image_path);
            if (img.empty()) {
                std::cerr << "无法加载图片: " << image_path << std::endl;
                continue;
            }

            // 缩放为全屏尺寸
            cv::resize(img, img, cv::Size(screen_width, screen_height));

            // 显示图像
            cv::imshow("Emotion Player", img);

            // 等待 20ms，按 ESC 键退出
            int key = cv::waitKey(20);
            if (key == 27) {
                return 0;
            }
        }
    }

    return 0;
}
