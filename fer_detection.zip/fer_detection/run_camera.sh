#!/bin/bash

export LD_LIBRARY_PATH=/home/yzh/Paddle-Lite-2.3.0/build.lite.armlinux.armv8.gcc/inference_lite_lib.armlinux.armv8/cxx/lib:$LD_LIBRARY_PATH


cd /home/yzh/Desktop/fer_detection/code/build


if [ "x$1" = "x" ]; then
    ./fer_detection ../models/face_detection ../models/fer_opt.nb
else
    # run
    ./fer_detection ../models/face_detection ../models/fer_opt.nb
fi
