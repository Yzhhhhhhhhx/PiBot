#!/usr/bin/env python3
import time
import signal
import sys
import subprocess
from pathlib import Path
import threading

# FIFO 文件路径
FIFO_PATH = "/home/yzh/Desktop/fer_detection/code/emotion_pipe"

# 不同情绪对应的音频文件列表
AUDIO_MAP = {
    "anger": [
        "/home/yzh/Desktop/fer_detection/angry.wav",
        "/home/yzh/Desktop/fer_detection/稻香.mp3",
    ],
    "happy": [
        "/home/yzh/Desktop/fer_detection/happy.wav",
        "/home/yzh/Desktop/fer_detection/青花瓷.mp3",
    ],
}

running = True
player_proc = None
player_thread = None
stop_playback_event = threading.Event()


def handle_sigint(signum, frame):
    global running
    print("\n[INFO] Exiting by SIGINT…")
    running = False
    stop_playback()

signal.signal(signal.SIGINT, handle_sigint)


def stop_playback():
    """停止当前播放线程和进程"""
    global player_proc, player_thread
    stop_playback_event.set()
    if player_proc:
        try:
            player_proc.terminate()
        except Exception:
            pass
    if player_thread and player_thread.is_alive():
        player_thread.join()
    stop_playback_event.clear()
    player_proc = None
    player_thread = None


def playback_task(files):
    """遍历文件列表播放音频，响应停止事件"""
    global player_proc
    for file_path in files:
        if stop_playback_event.is_set():
            break
        path = Path(file_path)
        if not path.exists():
            print(f"[WARN] File not found: {file_path}")
            continue
        print(f"▶ Playing {file_path}")
        try:
            proc = subprocess.Popen(["cvlc", "--play-and-exit", file_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except FileNotFoundError:
            ext = path.suffix.lower()
            player = "aplay" if ext == ".wav" else "mpg123" if ext == ".mp3" else None
            if player:
                proc = subprocess.Popen([player, file_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                print(f"[ERROR] Unsupported format: {ext}")
                continue
        player_proc = proc
        while proc.poll() is None:
            if stop_playback_event.is_set():
                try:
                    proc.terminate()
                except Exception:
                    pass
                break
            time.sleep(0.1)
    player_proc = None


def main():
    global player_thread
    fifo = Path(FIFO_PATH)
    if not fifo.exists() or not fifo.is_fifo():
        print(f"[ERROR] FIFO not found or not a pipe: {FIFO_PATH}")
        sys.exit(1)

    print(f"[INFO] Listening on FIFO: {FIFO_PATH}")
    with open(FIFO_PATH, "r") as f:
        while running:
            line = f.readline()
            if not line:
                time.sleep(0.1)
                continue
            cmd = line.strip().lower()
            if not cmd:
                continue
            # 如果检测到 normal，则停止音乐
            if cmd == "normal":
                print("[INFO] 'normal' detected, stopping playback.")
                stop_playback()
                continue
            # 如果检测到映射中的情绪，则播放对应音乐
            if cmd in AUDIO_MAP:
                print(f"[INFO] '{cmd}' detected, playing audio.")
                stop_playback()  # 停止当前阶段的播放
                files = AUDIO_MAP[cmd]
                player_thread = threading.Thread(target=playback_task, args=(files,), daemon=True)
                player_thread.start()
                continue
            # 其他情绪不做处理

    stop_playback()
    print("[INFO] Listener stopped.")


if __name__ == "__main__":
    main()
