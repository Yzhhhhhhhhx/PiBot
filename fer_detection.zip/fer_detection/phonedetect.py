// Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
#include <iostream>
#include <string>
#include <vector>
#include <arm_neon.h>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <chrono>
#include <thread>
#include <atomic>
#include "paddle_api.h"  // NOLINT
using namespace paddle::lite_api;  // NOLINT

// 前置声明 PlayEmotionAnimation 函数
void PlayEmotionAnimation(const std::string& emotion,
                          int frame_count,
                          int screen_width,
                          int screen_height,
                          int delay_ms);

#define max(a,b) ((a)>(b)?(a):(b))

struct Object {
  int batch_id;
  cv::Rect rec;
  int class_id;
  float prob;
};

int64_t ShapeProduction(const shape_t& shape) {
  int64_t res = 1;
  for (auto i : shape) res *= i;
  return res;
}

// fill tensor with mean and scale and trans layout: nhwc -> nchw, neon speed up
void neon_mean_scale(const float* din,
                     float* dout,
                     int size,
                     const std::vector<float> mean,
                     const std::vector<float> scale) {
  if (mean.size() != 3 || scale.size() != 3) {
    std::cerr << "[ERROR] mean or scale size must equal to 3\n";
    exit(1);
  }
  float32x4_t vmean0 = vdupq_n_f32(mean[0]);
  float32x4_t vmean1 = vdupq_n_f32(mean[1]);
  float32x4_t vmean2 = vdupq_n_f32(mean[2]);
  float32x4_t vscale0 = vdupq_n_f32(scale[0]);
  float32x4_t vscale1 = vdupq_n_f32(scale[1]);
  float32x4_t vscale2 = vdupq_n_f32(scale[2]);
  float* dout_c0 = dout;
  float* dout_c1 = dout + size;
  float* dout_c2 = dout + size * 2;
  int i = 0;
  for (; i < size - 3; i += 4) {
    float32x4x3_t vin3 = vld3q_f32(din);
    float32x4_t vsub0 = vsubq_f32(vin3.val[0], vmean0);
    float32x4_t vsub1 = vsubq_f32(vin3.val[1], vmean1);
    float32x4_t vsub2 = vsubq_f32(vin3.val[2], vmean2);
    float32x4_t vs0 = vmulq_f32(vsub0, vscale0);
    float32x4_t vs1 = vmulq_f32(vsub1, vscale1);
    float32x4_t vs2 = vmulq_f32(vsub2, vscale2);
    vst1q_f32(dout_c0, vs0);
    vst1q_f32(dout_c1, vs1);
    vst1q_f32(dout_c2, vs2);
    din += 12;       // 3 channels * 4 pixels = 12
    dout_c0 += 4;
    dout_c1 += 4;
    dout_c2 += 4;
  }
  for (; i < size; i++) {
    *(dout_c0++) = (*(din++) - mean[0]) * scale[0];
    *(dout_c1++) = (*(din++) - mean[1]) * scale[1];
    *(dout_c2++) = (*(din++) - mean[2]) * scale[2];
  }
}

void pre_process(const cv::Mat& img,
                 int width,
                 int height,
                 const std::vector<float>& mean,
                 const std::vector<float>& scale,
                 float* data,
                 bool is_scale = false) {
  cv::Mat resized_img;
  cv::resize(img, resized_img, cv::Size(width, height), 0.f, 0.f, cv::INTER_CUBIC);
  cv::Mat imgf;
  float scale_factor = is_scale ? 1.f / 256 : 1.f;
  resized_img.convertTo(imgf, CV_32FC3, scale_factor);
  const float* dimg = reinterpret_cast<const float*>(imgf.data);
  neon_mean_scale(dimg, data, width * height, mean, scale);
}

// 全局变量
std::string current_emotion = ""; // 当前播放的表情标签
std::chrono::steady_clock::time_point last_play_time = std::chrono::steady_clock::now();
std::atomic<bool> stop_animation{false};  // 控制动画播放的标志位
std::unique_ptr<std::thread> animation_thread = nullptr;  // 动画线程管理

cv::Mat RunModel(cv::Mat img,
                 std::shared_ptr<PaddlePredictor> &predictor,
                 std::shared_ptr<PaddlePredictor> &predictor2,
                 bool do_classification) {
  // Prepare
  float shrink = 0.2f;
  int width = img.cols;
  int height = img.rows;
  int s_width = static_cast<int>(width * shrink);
  int s_height = static_cast<int>(height * shrink);

  // 1) Get Input Tensor for detection
  std::unique_ptr<Tensor> input_tensor0(std::move(predictor->GetInput(0)));
  input_tensor0->Resize({1, 3, s_height, s_width});
  float* data = input_tensor0->mutable_data<float>();

  // 2) Do PreProcess for detection
  std::vector<float> detect_mean = {104.f, 117.f, 123.f};
  std::vector<float> detect_scale = {0.007843f, 0.007843f, 0.007843f};
  pre_process(img, s_width, s_height, detect_mean, detect_scale, data, false);

  // 3) Run detection
  predictor->Run();

  // 4) Get Output of detection
  std::unique_ptr<const Tensor> output_tensor0(std::move(predictor->GetOutput(0)));
  const float* outptr = output_tensor0->data<float>();
  auto shape_out = output_tensor0->shape();
  int64_t out_len = 1;
  for (auto dim : shape_out) {
    out_len *= dim;
  }

  // 5) Filter out detection boxes
  float detect_threshold = 0.7f;
  std::vector<Object> detect_result;
  for (int i = 0; i < out_len / 6; ++i) {
    float score = outptr[1];
    if (score >= detect_threshold) {
      Object obj;
      int xmin = static_cast<int>(width * outptr[2]);
      int ymin = static_cast<int>(height * outptr[3]);
      int xmax = static_cast<int>(width * outptr[4]);
      int ymax = static_cast<int>(height * outptr[5]);
      int w = xmax - xmin;
      int h = ymax - ymin;
      cv::Rect rec_clip =
          cv::Rect(xmin, ymin, w, h) & cv::Rect(0, 0, width, height);
      obj.rec = rec_clip;
      detect_result.push_back(obj);
    }
    outptr += 6;
  }

  // 6) Draw detection boxes on every frame
  for (const auto& obj : detect_result) {
    cv::rectangle(img, obj.rec, cv::Scalar(0, 0, 255), 2, cv::LINE_AA);
  }

  // 7) Perform classification only if do_classification is true and faces are detected
  if (do_classification && !detect_result.empty()) {
    // Prepare classification input
    std::unique_ptr<Tensor> input_tensor1(std::move(predictor2->GetInput(0)));
    int classify_w = 64;
    int classify_h = 64;
    input_tensor1->Resize({1, 3, classify_h, classify_w});
    float* input_data = input_tensor1->mutable_data<float>();
    std::vector<float> classify_mean = {0.336f, 0.336f, 0.336f};
    std::vector<float> classify_scale = {1.0f, 1.0f, 1.0f};
    // Use the first detected face for classification
    cv::Rect rec_clip = detect_result[0].rec;
    cv::Mat roi = img(rec_clip);
    // Preprocess for classification
    pre_process(roi, classify_w, classify_h, classify_mean, classify_scale, input_data, true);
    // Run classification
    predictor2->Run();
    // Get classification output
    std::unique_ptr<const Tensor> output_tensor1(std::move(predictor2->GetOutput(0)));
    const float* outptr_cls = output_tensor1->data<float>();
    // Determine emotion by finding the max score
    float temp = outptr_cls[0];
    temp = max(temp, outptr_cls[1]);
    temp = max(temp, outptr_cls[2]);
    temp = max(temp, outptr_cls[3]);

    // 获取表情标签
    std::string emotion_label;
    if (temp <= outptr_cls[0]) {
        emotion_label = "anger";
    } else if (temp <= outptr_cls[1]) {
        emotion_label = "happy";
    } else if (temp <= outptr_cls[2]) {
        emotion_label = "normal";
    } else {
        emotion_label = "surprised";
    }
    std::cout << emotion_label << std::endl;

    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_play_time).count();

    // 如果是新表情或超过 5 秒未播放，播放动画
    if (emotion_label != current_emotion || elapsed >= 5) {
        current_emotion = emotion_label;
        last_play_time = now;

        // 先终止旧线程（如果有）
        if (animation_thread && animation_thread->joinable()) {
            stop_animation = true;
            animation_thread->join();
        }

        // 启动新线程
        stop_animation = false;
        animation_thread.reset(new std::thread([current_emotion]() {
            PlayEmotionAnimation(current_emotion, 20, 800, 480, 20);  // 20 帧
        }));
    }
  }

  // Return the image with drawn boxes
  return img;
}

// 动画播放函数
void PlayEmotionAnimation(const std::string& emotion,
                          int frame_count,
                          int screen_width,
                          int screen_height,
                          int delay_ms) {
    std::string folder_path = "/home/yzh/Desktop/fer_detection/emotions/emotions/" + emotion;
    static bool window_created = false;
    if (!window_created) {
        cv::namedWindow("Emotion Player", cv::WINDOW_NORMAL);
        cv::setWindowProperty("Emotion Player", cv::WND_PROP_FULLSCREEN, cv::WINDOW_FULLSCREEN);
        window_created = true;
    }

    int frame_index = 0;
    while (!stop_animation) {
        std::string image_path = folder_path + "/frame" + std::to_string(frame_index % frame_count) + ".png";
        cv::Mat img = cv::imread(image_path);
        if (img.empty()) {
            std::cerr << "无法加载图片: " << image_path << std::endl;
            continue;
        }
        cv::resize(img, img, cv::Size(screen_width, screen_height));
        cv::imshow("Emotion Player", img);
        int key = cv::waitKey(delay_ms);
        if (key == 27) {  // 按 ESC 退出
            break;
        }
        frame_index++;
    }
}

int main(int argc, char** argv) {
  // 参数检查
  if (argc < 3) {
    std::cerr << "[ERROR] usage: " << argv[0]
              << " detect_model_dir classification_model_file [image_path]\n";
    return -1;
  }

  // 1) 解析参数
  std::string detect_model_dir = argv[1];
  std::string classify_model = argv[2];
  const int CPU_THREAD_NUM = 4;
  const paddle::lite_api::PowerMode CPU_POWER_MODE = paddle::lite_api::PowerMode::LITE_POWER_FULL;

  // 2) 配置与创建预测器：检测
  MobileConfig config;
  config.set_threads(CPU_THREAD_NUM);
  config.set_power_mode(CPU_POWER_MODE);
  config.set_model_dir(detect_model_dir); // 检测模型是个目录

  // 3) 配置与创建预测器：分类
  MobileConfig config2;
  config2.set_threads(CPU_THREAD_NUM);
  config2.set_power_mode(CPU_POWER_MODE);
  config2.set_model_from_file(classify_model); // 分类模型是 .nb 文件

  // 创建两个 Predictor
  std::shared_ptr<PaddlePredictor> predictor =
      CreatePaddlePredictor<MobileConfig>(config);
  std::shared_ptr<PaddlePredictor> predictor2 =
      CreatePaddlePredictor<MobileConfig>(config2);

  // 4) 判断是 图像模式 还是 摄像头模式
  if (argc == 4) {
    // 用户传了图片路径（图像模式）
    std::string img_path = argv[3];
    cv::Mat photo = cv::imread(img_path, cv::IMREAD_COLOR);
    if (photo.empty()) {
      std::cerr << "[ERROR] Cannot open image: " << img_path << std::endl;
      return -1;
    }
    bool do_classification = true; // 图像模式下始终执行表情识别
    RunModel(photo, predictor, predictor2, do_classification);
    cv::imshow("FER Demo", photo);
    cv::waitKey(0);
  } else if (argc == 3) {
    // 摄像头模式
    cv::VideoCapture cap(0);
    cap.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, 480);
    if (!cap.isOpened()) {
      std::cerr << "[ERROR] Can't open camera (index 0)" << std::endl;
      return -1;
    }

    // 初始化上一次表情识别的时间
    auto last_emotion_time = std::chrono::steady_clock::now();
    while (true) {
      cv::Mat input_image;
      cap >> input_image;
      if (input_image.empty()) {
        std::cerr << "[ERROR] Blank frame grabbed\n";
        break;
      }

      // 检查是否超过5秒
      auto now = std::chrono::steady_clock::now();
      auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_emotion_time).count();
      bool do_classification = (elapsed >= 5);
      if (do_classification) {
        last_emotion_time = now; // 重置时间
      }

      // 运行模型
      RunModel(input_image, predictor, predictor2, do_classification);

      // 显示结果
      cv::imshow("FER Demo", input_image);

      // 按下 'q' 或 '0' 退出
      char c = (char)cv::waitKey(1);
      if (c == 'q' || c == '0') {
        break;
      }
    }
    cap.release();
    cv::destroyAllWindows();
  } else {
    std::cerr << "[ERROR] usage: " << argv[0]
              << " detect_model_dir classification_model_file [image_path]\n";
    return -1;
  }

  // 结束时停止动画
  stop_animation = true;
  if (animation_thread && animation_thread->joinable()) {
      animation_thread->join();
  }
  cv::destroyWindow("Emotion Player");

  return 0;
}
