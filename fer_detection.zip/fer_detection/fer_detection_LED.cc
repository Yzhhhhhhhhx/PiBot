// Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <iostream>
#include <string>
#include <vector>

// 如果使用 neon_mean_scale，需要包含 arm_neon 头文件
#include <arm_neon.h>

#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "paddle_api.h"  // NOLINT

using namespace paddle::lite_api;  // NOLINT

#define max(a,b) ((a)>(b)?(a):(b))

struct Object {
  int batch_id;
  cv::Rect rec;
  int class_id;
  float prob;
};

int64_t ShapeProduction(const shape_t& shape) {
  int64_t res = 1;
  for (auto i : shape) res *= i;
  return res;
}

// fill tensor with mean and scale and trans layout: nhwc -> nchw, neon speed up
void neon_mean_scale(const float* din,
                     float* dout,
                     int size,
                     const std::vector<float> mean,
                     const std::vector<float> scale) {
  if (mean.size() != 3 || scale.size() != 3) {
    std::cerr << "[ERROR] mean or scale size must equal to 3\n";
    exit(1);
  }
  float32x4_t vmean0 = vdupq_n_f32(mean[0]);
  float32x4_t vmean1 = vdupq_n_f32(mean[1]);
  float32x4_t vmean2 = vdupq_n_f32(mean[2]);
  float32x4_t vscale0 = vdupq_n_f32(scale[0]);
  float32x4_t vscale1 = vdupq_n_f32(scale[1]);
  float32x4_t vscale2 = vdupq_n_f32(scale[2]);

  float* dout_c0 = dout;
  float* dout_c1 = dout + size;
  float* dout_c2 = dout + size * 2;

  int i = 0;
  for (; i < size - 3; i += 4) {
    float32x4x3_t vin3 = vld3q_f32(din);
    float32x4_t vsub0 = vsubq_f32(vin3.val[0], vmean0);
    float32x4_t vsub1 = vsubq_f32(vin3.val[1], vmean1);
    float32x4_t vsub2 = vsubq_f32(vin3.val[2], vmean2);
    float32x4_t vs0 = vmulq_f32(vsub0, vscale0);
    float32x4_t vs1 = vmulq_f32(vsub1, vscale1);
    float32x4_t vs2 = vmulq_f32(vsub2, vscale2);
    vst1q_f32(dout_c0, vs0);
    vst1q_f32(dout_c1, vs1);
    vst1q_f32(dout_c2, vs2);

    din += 12;       // 3 channels * 4 pixels = 12
    dout_c0 += 4;
    dout_c1 += 4;
    dout_c2 += 4;
  }
  for (; i < size; i++) {
    *(dout_c0++) = (*(din++) - mean[0]) * scale[0];
    *(dout_c1++) = (*(din++) - mean[1]) * scale[1];
    *(dout_c2++) = (*(din++) - mean[2]) * scale[2];
  }
}

void pre_process(const cv::Mat& img,
                 int width,
                 int height,
                 const std::vector<float>& mean,
                 const std::vector<float>& scale,
                 float* data,
                 bool is_scale = false) {
  cv::Mat resized_img;
  cv::resize(img, resized_img, cv::Size(width, height), 0.f, 0.f, cv::INTER_CUBIC);
  cv::Mat imgf;
  float scale_factor = is_scale ? 1.f / 256 : 1.f;
  resized_img.convertTo(imgf, CV_32FC3, scale_factor);
  const float* dimg = reinterpret_cast<const float*>(imgf.data);
  neon_mean_scale(dimg, data, width * height, mean, scale);
}

cv::Mat RunModel(cv::Mat img,
                 std::shared_ptr<paddle::lite_api::PaddlePredictor> &predictor,
                 std::shared_ptr<paddle::lite_api::PaddlePredictor> &predictor2) {
  // Prepare
  float shrink = 0.2f;
  int width = img.cols;
  int height = img.rows;
  int s_width = static_cast<int>(width * shrink);
  int s_height = static_cast<int>(height * shrink);

  // 1) Get Input Tensor for detection
  std::unique_ptr<Tensor> input_tensor0(std::move(predictor->GetInput(0)));
  input_tensor0->Resize({1, 3, s_height, s_width});
  float* data = input_tensor0->mutable_data<float>();

  // 2) Do PreProcess for detection
  std::vector<float> detect_mean = {104.f, 117.f, 123.f};
  std::vector<float> detect_scale = {0.007843f, 0.007843f, 0.007843f};
  pre_process(img, s_width, s_height, detect_mean, detect_scale, data, false);

  // 3) Run detection
  predictor->Run();

  // 4) Get Output of detection
  std::unique_ptr<const Tensor> output_tensor0(std::move(predictor->GetOutput(0)));
  const float* outptr = output_tensor0->data<float>();
  auto shape_out = output_tensor0->shape();
  int64_t out_len = 1;
  for (auto dim : shape_out) {
    out_len *= dim;
  }

  // 5) Filter out detection boxes
  float detect_threshold = 0.7f;
  std::vector<Object> detect_result;
  for (int i = 0; i < out_len / 6; ++i) {
    float score = outptr[1];
    if (score >= detect_threshold) {
      Object obj;
      int xmin = static_cast<int>(width * outptr[2]);
      int ymin = static_cast<int>(height * outptr[3]);
      int xmax = static_cast<int>(width * outptr[4]);
      int ymax = static_cast<int>(height * outptr[5]);
      int w = xmax - xmin;
      int h = ymax - ymin;
      cv::Rect rec_clip =
          cv::Rect(xmin, ymin, w, h) & cv::Rect(0, 0, width, height);
      obj.rec = rec_clip;
      detect_result.push_back(obj);
    }
    outptr += 6;
  }

  // 6) 准备分类
  std::unique_ptr<Tensor> input_tensor1(std::move(predictor2->GetInput(0)));
  int classify_w = 64;
  int classify_h = 64;
  input_tensor1->Resize({1, 3, classify_h, classify_w});
  float* input_data = input_tensor1->mutable_data<float>();

  std::vector<float> classify_mean = {0.336f, 0.336f, 0.336f};
  std::vector<float> classify_scale = {1.0f, 1.0f, 1.0f};

  // 只取检测到的第一张人脸做表情识别
  if (!detect_result.empty()) {
    cv::Rect rec_clip = detect_result[0].rec;
    cv::Mat roi = img(rec_clip);

    // 7) 预处理分类输入
    pre_process(roi, classify_w, classify_h, classify_mean, classify_scale, input_data, true);

    // 8) Run classification
    predictor2->Run();

    // 9) Get classification output
    std::unique_ptr<const Tensor> output_tensor1(std::move(predictor2->GetOutput(0)));
    const float* outptr_cls = output_tensor1->data<float>();

    // 10) 画框 + 识别结果
    cv::rectangle(img, rec_clip, cv::Scalar(0, 0, 255), 2, cv::LINE_AA);

    // 简单取最大值分类
    float temp = outptr_cls[0];
    temp = max(temp, outptr_cls[1]);
    temp = max(temp, outptr_cls[2]);
    temp = max(temp, outptr_cls[3]);

    // 这里你可以根据结果做想做的事，比如打印、显示文字等
    // 下面只是简单打印分类结果
    if (temp <= outptr_cls[0]) {
      std::cout << "anger" << std::endl;
    } else if (temp <= outptr_cls[1]) {
      std::cout << "happy" << std::endl;
    } else if (temp <= outptr_cls[2]) {
      std::cout << "normal" << std::endl;
    } else {
      std::cout << "surprised" << std::endl;
    }
  }

  // 返回画好框的图像
  return img;
}

int main(int argc, char** argv) {
  // 参数检查
  if (argc < 3) {
    std::cerr << "[ERROR] usage: " << argv[0]
              << " detect_model_dir classification_model_file [image_path]\n";
    return -1;
  }

  // 1) 解析参数
  std::string detect_model_dir = argv[1];
  std::string classify_model = argv[2];

  const int CPU_THREAD_NUM = 4;
  const paddle::lite_api::PowerMode CPU_POWER_MODE = paddle::lite_api::PowerMode::LITE_POWER_FULL;

  // 2) 配置与创建预测器：检测
  MobileConfig config;
  config.set_threads(CPU_THREAD_NUM);
  config.set_power_mode(CPU_POWER_MODE);
  config.set_model_dir(detect_model_dir); // 检测模型是个目录

  // 3) 配置与创建预测器：分类
  MobileConfig config2;
  config2.set_threads(CPU_THREAD_NUM);
  config2.set_power_mode(CPU_POWER_MODE);
  config2.set_model_from_file(classify_model); // 分类模型是 .nb 文件

  // 创建两个 Predictor
  std::shared_ptr<PaddlePredictor> predictor =
      CreatePaddlePredictor<MobileConfig>(config);
  std::shared_ptr<PaddlePredictor> predictor2 =
      CreatePaddlePredictor<MobileConfig>(config2);

  // 4) 判断是 图像模式 还是 摄像头模式
  if (argc == 4) {
    // 用户传了图片路径
    std::string img_path = argv[3];
    cv::Mat photo = cv::imread(img_path, cv::IMREAD_COLOR);
    if (photo.empty()) {
      std::cerr << "[ERROR] Cannot open image: " << img_path << std::endl;
      return -1;
    }
    RunModel(photo, predictor, predictor2);
    cv::waitKey(0);

  } else if (argc == 3) {
    // 摄像头模式
    cv::VideoCapture cap(0);
    cap.set(cv::CAP_PROP_FRAME_WIDTH, 640);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, 480);

    if (!cap.isOpened()) {
      std::cerr << "[ERROR] Can't open camera (index 0)" << std::endl;
      return -1;
    }
    while (true) {
      cv::Mat input_image;
      cap >> input_image;
      if (input_image.empty()) {
        std::cerr << "[ERROR] Blank frame grabbed\n";
        break;
      }
      RunModel(input_image, predictor, predictor2);
      // 可视化窗口
      cv::imshow("FER Demo", input_image);

      // 按下 'q' 或 '0' 退出
      char c = (char)cv::waitKey(1);
      if (c == 'q' || c == '0') {
        break;
      }
    }
    cap.release();
    cv::destroyAllWindows();

  } else {
    std::cerr << "[ERROR] usage: " << argv[0]
              << " detect_model_dir classification_model_file [image_path]\n";
    return -1;
  }

  return 0;
}  
