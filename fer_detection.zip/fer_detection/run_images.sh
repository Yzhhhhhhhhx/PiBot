
cd /home/yzh/Desktop/fer_detection/code/build



if [ "x$1" = "x" ]; then

LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${PADDLE_LITE_DIR}/libs/${TARGET_ARCH_ABI} ./fer_detection ../models/face_detection ../models/fer527.nb
else
#run
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${PADDLE_LITE_DIR}/libs/${TARGET_ARCH_ABI} ./fer_detection ../models/face_detection ../models/fer527.nb
fi
