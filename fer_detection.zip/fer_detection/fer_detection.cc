// Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <iostream>
#include <string>
#include <vector>
#include <arm_neon.h>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <chrono>
#include <thread>
#include <atomic>
#include "paddle_api.h"  // NOLINT

using namespace paddle::lite_api;  // NOLINT

// 前置声明 PlayEmotionAnimation 函数
void PlayEmotionAnimation(const std::string& emotion,
                          int frame_count,
                          int screen_width,
                          int screen_height,
                          int delay_ms);

#define max(a,b) ((a)>(b)?(a):(b))

struct Object {
  int batch_id;
  cv::Rect rec;
  int class_id;
  float prob;
};

int64_t ShapeProduction(const shape_t& shape) {
  int64_t res = 1;
  for (auto i : shape) res *= i;
  return res;
}

// fill tensor with mean and scale and trans layout: nhwc -> nchw, neon speed up
void neon_mean_scale(const float* din,
                     float* dout,
                     int size,
                     const std::vector<float> mean,
                     const std::vector<float> scale) {
  if (mean.size() != 3 || scale.size() != 3) {
    std::cerr << "[ERROR] mean or scale size must equal to 3\n";
    exit(1);
  }
  float32x4_t vmean0 = vdupq_n_f32(mean[0]);
  float32x4_t vmean1 = vdupq_n_f32(mean[1]);
  float32x4_t vmean2 = vdupq_n_f32(mean[2]);
  float32x4_t vscale0 = vdupq_n_f32(scale[0]);
  float32x4_t vscale1 = vdupq_n_f32(scale[1]);
  float32x4_t vscale2 = vdupq_n_f32(scale[2]);
  float* dout_c0 = dout;
  float* dout_c1 = dout + size;
  float* dout_c2 = dout + size * 2;
  int i = 0;
  for (; i < size - 3; i += 4) {
    float32x4x3_t vin3 = vld3q_f32(din);
    float32x4_t vsub0 = vsubq_f32(vin3.val[0], vmean0);
    float32x4_t vsub1 = vsubq_f32(vin3.val[1], vmean1);
    float32x4_t vsub2 = vsubq_f32(vin3.val[2], vmean2);
    float32x4_t vs0 = vmulq_f32(vsub0, vscale0);
    float32x4_t vs1 = vmulq_f32(vsub1, vscale1);
    float32x4_t vs2 = vmulq_f32(vsub2, vscale2);
    vst1q_f32(dout_c0, vs0);
    vst1q_f32(dout_c1, vs1);
    vst1q_f32(dout_c2, vs2);
    din += 12;       // 3 channels * 4 pixels = 12
    dout_c0 += 4;
    dout_c1 += 4;
    dout_c2 += 4;
  }
  for (; i < size; i++) {
    *(dout_c0++) = (*(din++) - mean[0]) * scale[0];
    *(dout_c1++) = (*(din++) - mean[1]) * scale[1];
    *(dout_c2++) = (*(din++) - mean[2]) * scale[2];
  }
}

void pre_process(const cv::Mat& img,
                 int width,
                 int height,
                 const std::vector<float>& mean,
                 const std::vector<float>& scale,
                 float* data,
                 bool is_scale = false) {
  cv::Mat resized_img;
  cv::resize(img, resized_img, cv::Size(width, height), 0.f, 0.f, cv::INTER_CUBIC);
  cv::Mat imgf;
  float scale_factor = is_scale ? 1.f / 256 : 1.f;
  resized_img.convertTo(imgf, CV_32FC3, scale_factor);
  const float* dimg = reinterpret_cast<const float*>(imgf.data);
  neon_mean_scale(dimg, data, width * height, mean, scale);
}

// 全局变量
std::string current_emotion = ""; // 当前表情
std::chrono::steady_clock::time_point last_play_time = std::chrono::steady_clock::now();
std::chrono::steady_clock::time_point last_print_time = std::chrono::steady_clock::now(); // 打印间隔控制
std::atomic<bool> stop_animation{false};  // 控制动画播放的标志位
std::unique_ptr<std::thread> animation_thread = nullptr;  // 动画线程管理

cv::Mat RunModel(cv::Mat img,
                 std::shared_ptr<PaddlePredictor> &predictor,
                 std::shared_ptr<PaddlePredictor> &predictor2,
                 bool /*do_classification*/) {
  // Prepare
  float shrink = 0.2f;
  int width = img.cols;
  int height = img.rows;
  int s_width = static_cast<int>(width * shrink);
  int s_height = static_cast<int>(height * shrink);
  // 1) Get Input Tensor for detection
  std::unique_ptr<Tensor> input_tensor0(std::move(predictor->GetInput(0)));
  input_tensor0->Resize({1, 3, s_height, s_width});
  float* data = input_tensor0->mutable_data<float>();
  // 2) Do PreProcess for detection
  std::vector<float> detect_mean = {104.f, 117.f, 123.f};
  std::vector<float> detect_scale = {0.007843f, 0.007843f, 0.007843f};
  pre_process(img, s_width, s_height, detect_mean, detect_scale, data, false);
  // 3) Run detection
  predictor->Run();
  // 4) Get Output of detection
  std::unique_ptr<const Tensor> output_tensor0(std::move(predictor->GetOutput(0)));
  const float* outptr = output_tensor0->data<float>();
  auto shape_out = output_tensor0->shape();
  int64_t out_len = 1;
  for (auto dim : shape_out) out_len *= dim;
  // 5) Filter out detection boxes
  float detect_threshold = 0.7f;
  std::vector<Object> detect_result;
  for (int i = 0; i < out_len / 6; ++i) {
    float score = outptr[1];
    if (score >= detect_threshold) {
      Object obj;
      int xmin = static_cast<int>(width * outptr[2]);
      int ymin = static_cast<int>(height * outptr[3]);
      int xmax = static_cast<int>(width * outptr[4]);
      int ymax = static_cast<int>(height * outptr[5]);
      int w = xmax - xmin;
      int h = ymax - ymin;
      cv::Rect rec_clip =
          cv::Rect(xmin, ymin, w, h) & cv::Rect(0, 0, width, height);
      obj.rec = rec_clip;
      detect_result.push_back(obj);
    }
    outptr += 6;
  }
  // 6) Draw detection boxes on every frame
  for (const auto& obj : detect_result) {
    cv::rectangle(img, obj.rec, cv::Scalar(0, 0, 255), 2, cv::LINE_AA);
  }
  // 7) Perform classification and animation logic
  if (!detect_result.empty()) {
    // Prepare classification input
    std::unique_ptr<Tensor> input_tensor1(std::move(predictor2->GetInput(0)));
    int classify_w = 64;
    int classify_h = 64;
    input_tensor1->Resize({1, 3, classify_h, classify_w});
    float* input_data = input_tensor1->mutable_data<float>();
    std::vector<float> classify_mean = {0.336f, 0.336f, 0.336f};
    std::vector<float> classify_scale = {1.0f, 1.0f, 1.0f};
    cv::Mat roi = img(detect_result[0].rec);
    pre_process(roi, classify_w, classify_h, classify_mean, classify_scale, input_data, true);
    predictor2->Run();
    std::unique_ptr<const Tensor> output_tensor1(std::move(predictor2->GetOutput(0)));
    const float* outptr_cls = output_tensor1->data<float>();
    // Determine emotion label
    float max_score = outptr_cls[0];
    for (int i = 1; i < 4; ++i) max_score = max(max_score, outptr_cls[i]);
    std::string emotion_label;
    if (max_score == outptr_cls[0])      emotion_label = "anger";
    else if (max_score == outptr_cls[1]) emotion_label = "happy";
    else if (max_score == outptr_cls[2]) emotion_label = "normal";
    else                                  emotion_label = "surprised";
    // Periodic print every 5 seconds
    auto now = std::chrono::steady_clock::now();
    auto since_print = std::chrono::duration_cast<std::chrono::seconds>(now - last_print_time).count();
    if (since_print >= 5) {
      std::cout << emotion_label << std::endl;
      last_print_time = now;
    }
    // Animation debounce: new label or >=5s since last play
        auto since_play = std::chrono::duration_cast<std::chrono::seconds>(now - last_play_time).count();
    if (since_play >= 5) {
      current_emotion = emotion_label; // 更新当前表情
      last_play_time = now; // 更新最后播放时间

      // 终止旧动画线程
      if (animation_thread && animation_thread->joinable()) {
        stop_animation = true;
        animation_thread->join();
      }
      stop_animation = false;

      // 启动新动画线程
      animation_thread.reset(new std::thread([emotion_label]() {
        PlayEmotionAnimation(emotion_label, 20, 800, 480, 20);
      }));
    }
  } else {
    // 未检测到人脸时的逻辑（同样遵循5秒规则）
    std::string emotion_label = "blink";
    auto now = std::chrono::steady_clock::now();
    auto since_play = std::chrono::duration_cast<std::chrono::seconds>(now - last_play_time).count();
    if (since_play >= 5) {
      current_emotion = emotion_label; // 更新当前表情
      last_play_time = now; // 更新最后播放时间

      // 终止旧动画线程
      if (animation_thread && animation_thread->joinable()) {
        stop_animation = true;
        animation_thread->join();
      }
      stop_animation = false;

      // 启动新动画线程
      animation_thread.reset(new std::thread([emotion_label]() {
        PlayEmotionAnimation(emotion_label, 20, 800, 480, 20);
      }));
    }
  }
  return img;
}

// 动画播放函数 - 修改为全屏显示
void PlayEmotionAnimation(const std::string& emotion,
                          int frame_count,
                          int screen_width,
                          int screen_height,
                          int delay_ms) {
    std::string folder_path = "/home/yzh/Desktop/fer_detection/emotions/emotions/" + emotion;
    static bool window_created = false;
    if (!window_created) {
        cv::namedWindow("Emotion Player", cv::WINDOW_NORMAL);
        // 设置窗口大小为屏幕分辨率
        cv::resizeWindow("Emotion Player", screen_width, screen_height);
        // 移动窗口到屏幕左上角 (0,0)
        cv::moveWindow("Emotion Player", 0, 0);
        // 设置全屏属性
        cv::setWindowProperty("Emotion Player", cv::WND_PROP_FULLSCREEN, cv::WINDOW_FULLSCREEN);
        window_created = true;
    }
    int frame_index = 0;
    while (!stop_animation) {
        std::string image_path = folder_path + "/frame" + std::to_string(frame_index % frame_count) + ".png";
        cv::Mat img = cv::imread(image_path);
        if (img.empty()) {
            std::cerr << "无法加载图片: " << image_path << std::endl;
            continue;
        }
        // 调整图像大小以匹配屏幕分辨率
        cv::resize(img, img, cv::Size(screen_width, screen_height));
        cv::imshow("Emotion Player", img);
        int key = cv::waitKey(delay_ms);
        if (key == 27) break; // ESC
        frame_index++;
    }
}

int main(int argc, char** argv) {
  if (argc < 3) {
    std::cerr << "[ERROR] usage: " << argv[0]
              << " detect_model_dir classification_model_file [image_path]\n";
    return -1;
  }
  std::string detect_model_dir = argv[1];
  std::string classify_model = argv[2];
  const int CPU_THREAD_NUM = 4;
  const paddle::lite_api::PowerMode CPU_POWER_MODE = paddle::lite_api::PowerMode::LITE_POWER_FULL;
  MobileConfig config;
  config.set_threads(CPU_THREAD_NUM);
  config.set_power_mode(CPU_POWER_MODE);
  config.set_model_dir(detect_model_dir);
  MobileConfig config2;
  config2.set_threads(CPU_THREAD_NUM);
  config2.set_power_mode(CPU_POWER_MODE);
  config2.set_model_from_file(classify_model);
  auto predictor  = CreatePaddlePredictor<MobileConfig>(config);
  auto predictor2 = CreatePaddlePredictor<MobileConfig>(config2);

  if (argc == 4) {
    cv::Mat photo = cv::imread(argv[3]);
    if (photo.empty()) {
      std::cerr << "[ERROR] Cannot open image: " << argv[3] << std::endl;
      return -1;
    }
    // 仅进行推理，不显示图像
    RunModel(photo, predictor, predictor2, true);
    // 等待动画播放完成
    if (animation_thread && animation_thread->joinable()) {
      stop_animation = true;
      animation_thread->join();
    }
  } else {
    cv::VideoCapture cap(0);
    cap.set(cv::CAP_PROP_FRAME_WIDTH, 800);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, 400);
    if (!cap.isOpened()) {
      std::cerr << "[ERROR] Can't open camera (index 0)" << std::endl;
      return -1;
    }
    while (true) {
      cv::Mat frame;
      cap >> frame;
      if (frame.empty()) break;
      // 仅进行表情检测，不显示原始画面
      RunModel(frame, predictor, predictor2, true);
      // 添加适当的等待时间，避免主线程过快运行
      std::this_thread::sleep_for(std::chrono::milliseconds(30));
    }
    cap.release();
  }

  stop_animation = true;
  if (animation_thread && animation_thread->joinable()) animation_thread->join();
  cv::destroyWindow("Emotion Player");
  return 0;
}
